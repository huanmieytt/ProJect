package com.thinkgem.jeesite.common.beanvalidator;

/**
 * 添加Bean验证组
 * @author ThinkGem
 *
 */
public interface AddGroup {

}
